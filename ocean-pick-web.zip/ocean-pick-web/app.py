from flask import Flask, jsonify
import mysql.connector

app = Flask(__name__)

# Connect to the database
def connect_to_database():
    try:
        connection = mysql.connector.connect(
            host="localhost",  # Replace with your host address if MySQL is hosted elsewhere
            user="root",      # Your MySQL username
            password="",      # Your MySQL password (if you have set any)
            database="ocean_pick"  # Your database name
        )
        return connection
    except mysql.connector.Error as e:
        print("Error connecting to MySQL:", e)
        return None

# Route for checking database connection
@app.route("/check_connection")
def check_connection():
    connection = connect_to_database()
    if connection is not None and connection.is_connected():
        connection.close()
        return jsonify({"status": "success", "message": "Connected to the MySQL database"})
    else:
        return jsonify({"status": "error", "message": "Failed to connect to the MySQL database"})
    
    # Route to display the form
@app.route("/add_feed", methods=["GET"])
def add_feed_form():
    return render_template("add_feed.html")

# Route to handle form submission and insert data into the database
@app.route("/add_feed", methods=["POST"])
def add_feed():
    connection = connect_to_database()
    if connection is not None and connection.is_connected():
        cursor = connection.cursor()
        # Get form data
        feed_id = request.form.get("feed_id")
        feed_type = request.form.get("type")
        code = request.form.get("code")
        weight = request.form.get("weight")
        quantity = request.form.get("quantity")
        user_id = request.form.get("user_id")
        # Insert data into the database
        cursor.execute("INSERT INTO feeds (feed_id, type, code, weight, quantity, user_id) VALUES (%s, %s, %s, %s, %s, %s)", (feed_id, feed_type, code, weight, quantity, user_id))
        connection.commit()
        cursor.close()
        connection.close()
        return jsonify({"status": "success", "message": "Feed added successfully"})
    else:
        return jsonify({"status": "error", "message": "Failed to add feed. Database connection failed."})
    
# Route to display feed data in table format
@app.route("/feeds")
def show_feeds():
    connection = connect_to_database()
    if connection is not None and connection.is_connected():
        cursor = connection.cursor(dictionary=True)
        cursor.execute("SELECT * FROM feeds")
        feeds = cursor.fetchall()
        cursor.close()
        connection.close()
        return render_template("feed_table.html", feeds=feeds)
    else:
        return jsonify({"status": "error", "message": "Failed to fetch feed data. Database connection failed."})

    
#users
# Function to execute query and fetch users
def fetch_users():
    connection = connect_to_database()
    if connection is not None and connection.is_connected():
        cursor = connection.cursor(dictionary=True)
        query = "SELECT * FROM users"
        cursor.execute(query)
        users = cursor.fetchall()
        connection.close()
        return users
    else:
        return None

# Route for listing users
@app.route("/list_users")
def list_users():
    users = fetch_users()
    if users is not None:
        return jsonify({"status": "success", "users": users})
    else:
        return jsonify({"status": "error", "message": "Failed to fetch users"})

if __name__ == "__main__":
    app.run(debug=True)
